

#include "sensor_queue.h"
#include "debug.h"


#define QUEUE_SEND_FREQUENCY_MS         ( 200 / portTICK_PERIOD_MS )
#define QUEUE_LENGTH                    ( 1 )

QueueHandle_t xQueue;


void sensorq_create ( void ){
	 xQueue = xQueueCreate( 16, sizeof(uint32_t));
     if( xQueue == NULL )
    {
        dbgOutputVal(3);
    }
     
}

void sensorq_send(uint32_t inVal){
	//sends data
    struct AMessage *pxMessage;
    xMessage.val = inVal;
    xMessage.unit[0] = 'c';
    xMessage.unit[1] = 'm';
    
    
    pxMessage = &xMessage;
     //dbgOutputVal(1);
	 xQueueSendToBackFromISR( xQueue, ( void * ) &pxMessage, (BaseType_t) 0);	
     
     //xQueueSendFromISR(xQueue, &val, true);
     //dbgOutputVal(2);


	
}

struct AMessage* sensorq_receive( void){
	
    const struct AMessage *inMessage;
	if(xQueueReceive( xQueue, &inMessage, portMAX_DELAY )){
        return inMessage;
    }
    
	
}

/*******************************************************************************
 End of File
 */